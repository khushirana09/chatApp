//importing required modules

const express = require("express");
const bcrypt = require("bcryptjs"); // for hashing passwords
const jwt = require("jsonwebtoken"); //for creating token
const User = require("../models/User"); // user model from MONGODB
const router = express.Router(); //creating a router

//register route - post /api /register

router.post("/register", async (req, res) => {
  const { username, password } = req.body;

  try {
    //check if username is already taken

    let user = await User.findOne({ username });
    if (user) return res.status(400).json({ msg: "Username already exists" });

    //hash the password using bcrypt
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    //create new user in mongodb
    user = new User({ username, password: hashedPassword });
    await user.save();

    res.status(201).json({ msg: "User registered successfully" });
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server error");
  }
});

/// LOGIN ROUTE - POST /API/LOGIN

router.post("/login", async (req, res) => {
  const { username, password } = req.body;

  try {
    //check if the user exists in db
    const user = await User.findOne({ username });
    if (!user) return res.status(400).json({ msg: "Invaild credentials" });

    //compared password with hash password

    const iMatch = await bcrypt.compare(password, user.password);
    if (!isMatch)
      return res.status(400) - express.json({ msg: "Invalid credentials" });

    //Create JWT TOKEN WITH USER ID INSIDE
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
      expiresIn: "1h", //expires in 1 hour
    });

    // send token and username to frontend
    res.json({ token, username: user.username });
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server error");
  }
});

module.exports = router;
