require("dotenv").config(); 
// Import required modules
const express = require('express');
const http = require('http');
const cors = require('cors');
const mongoose = require('mongoose');
const socketIo = require('socket.io');
const dotenv = require('dotenv');
const authRoutes = require('./routes/auth'); // Authentication routes

// Load environment variables from .env file
dotenv.config();

// Initialize Express app
const app = express();

// Create HTTP server from Express app
const server = http.createServer(app);

// Setup Socket.io on the HTTP server
const io = socketIo(server, {
  cors: {
    origin: '*', // Allow all origins — in production, restrict this!
    methods: ['GET', 'POST']
  }
});

// Middleware: Enable CORS and parse JSON request bodies
app.use(cors());
app.use(express.json());

// Connect to MongoDB using Mongoose
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => console.log('✅ MongoDB Connected'))
  .catch(err => console.log('❌ MongoDB Error:', err));

// Route middleware for authentication endpoints
app.use('/api', authRoutes); // Register + Login endpoints will use /api prefix

// Store connected users
let onlineUsers = {}; // Example: { socketId1: 'John', socketId2: 'Alice' }

// Handle Socket.io events
io.on('connection', (socket) => {
  console.log('🔌 New socket connected:', socket.id);

  // When a user joins with their username
  socket.on('setUsername', (username) => {
    onlineUsers[socket.id] = username; // Save username with socket id
    console.log(`👤 ${username} connected`);

    // Send updated user list to all clients
    io.emit('updateUserList', Object.values(onlineUsers));
  });

  // When a user sends a message
  socket.on('chatMessage', (message) => {
    const username = onlineUsers[socket.id];
    if (username) {
      const msg = { user: username, text: message };

      // Broadcast message to all clients
      io.emit('chatMessage', msg);
    }
  });

  // When a user disconnects
  socket.on('disconnect', () => {
    const disconnectedUser = onlineUsers[socket.id];
    delete onlineUsers[socket.id];
    console.log(`❌ ${disconnectedUser} disconnected`);

    // Update user list for all clients
    io.emit('updateUserList', Object.values(onlineUsers));
  });
});

// Start the server
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});
